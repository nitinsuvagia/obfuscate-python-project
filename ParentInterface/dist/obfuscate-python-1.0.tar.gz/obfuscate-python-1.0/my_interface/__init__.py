# my_interface/__init__.py
from .parent_interface import ParentInterface
